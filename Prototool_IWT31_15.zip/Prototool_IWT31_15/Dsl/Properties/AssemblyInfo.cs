#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"UPM_IPS")]
[assembly: AssemblyProduct(@"Prototool_IWT31_15")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"Company.Prototool_IWT31_15.DslPackage, PublicKey=002400000480000094000000060200000024000052534131000400000100010081C7C4D8D31A509760F4F7680AACA497D777B0596F53C448E66A6A09EB3DCD060A00674EB8F23DEB6A7A3FDAB22F3DF99BEEF8426E8AE3D1F2057CA0A36F5CEB9004AD171BACA4146B151BE44281F485BAD163AFB4CB6FD6ADFCE775B7F860F9246DD4986F3EBB59AFC43242503A605F2D4F8D51E5D6D0339610DC1E93B87BE0")]