﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IPS.Prototool_IWT31_15
{
    public partial class VentanaPrincipal
    {
        public string GetNombreCalculado() { return "aa"}
    }
}
